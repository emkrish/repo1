# Kafka + Debezium Node 2

Run: docker compose up -d
