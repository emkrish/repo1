#!/bin/bash
docker exec -it cdc_kafka kafka-console-consumer --bootstrap-server localhost:9092 --topic pgcdc.public.customers --from-beginning
