# PostgreSQL CDC Node 1

Run: docker compose up -d
